package com.hcl.rentaplace.exception;

/*
 * Author: Keerthana
 * Date: 18/01/2023
 */

public class ReservationNotFoundException extends Exception{

}

package com.example.userreviewmicroservice.ui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserReviewMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}

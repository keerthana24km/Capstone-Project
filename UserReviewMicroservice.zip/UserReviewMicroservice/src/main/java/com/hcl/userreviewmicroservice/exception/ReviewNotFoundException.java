package com.hcl.userreviewmicroservice.exception;

/*
 * Author: Keerthana
 * Date: 18/01/2023
 */

public class ReviewNotFoundException extends Exception{
	
}

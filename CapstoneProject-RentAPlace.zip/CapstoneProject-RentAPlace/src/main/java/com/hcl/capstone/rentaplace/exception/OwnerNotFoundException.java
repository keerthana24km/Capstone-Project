package com.hcl.capstone.rentaplace.exception;

public class OwnerNotFoundException extends Exception{

}

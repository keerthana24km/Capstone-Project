package com.hcl.capstone.rentaplace.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.capstone.rentaplace.entity.User;
import com.hcl.capstone.rentaplace.repository.IUserRepository;


@Service
public class UserService implements IUserService {
	
	@Autowired
	private IUserRepository repo;
	
	public User Register(User user) {
		return repo.save(user);

	}
	
	public User login(String userName,String userPassword)
	{
		return repo.findUserByNameAndPassword(userName,userPassword).orElse(null);
	}
	  
	  public List<User> getAll()
	  {
		  return (List<User>) repo.findAll();
	  }
	  
	  public User update(long id, User user) {
		  User user1 = repo.findById(id).get();
		  user1.setUserName(user.getUserName());
		  user1.setemail(user.getemail());
		  user1.setuserPassword(user.getuserPassword());
		  
		  return repo.save(user1);
	  }
	 
	  public String delete(User user) 
	  {
		  repo.delete(user);
		  return "Deletion Successful!";
	  }
	  
	  public Optional<User> get(Long userId)
	  {
		  return repo.findById(userId);
	  }
	

}


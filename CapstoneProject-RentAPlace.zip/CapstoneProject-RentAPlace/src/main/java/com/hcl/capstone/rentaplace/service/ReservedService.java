package com.hcl.capstone.rentaplace.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.capstone.rentaplace.entity.Reserved;
import com.hcl.capstone.rentaplace.repository.IReservedRepository;

@Service
public class ReservedService implements IReservedService{

	@Autowired
	IReservedRepository reservedRepo;
	
	@Override
	public List<Reserved> getAllReservations() {
		// TODO Auto-generated method stub
		return reservedRepo.findAll();
	}

}

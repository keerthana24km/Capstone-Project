package com.hcl.capstone.rentaplace.exception;

public class PropertyNotFoundException extends Exception{

}

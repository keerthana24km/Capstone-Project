package com.hcl.capstone.rentaplace.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.capstone.rentaplace.entity.Owner;


@Repository
public interface IOwnerRepository extends JpaRepository<Owner, Long> {

	public Owner findOwnerByNameAndPassword(String ownerName, String ownerPassword);
	
}

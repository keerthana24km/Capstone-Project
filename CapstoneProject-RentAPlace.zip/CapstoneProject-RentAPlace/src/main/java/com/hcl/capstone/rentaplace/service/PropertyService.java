package com.hcl.capstone.rentaplace.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.capstone.rentaplace.entity.Property;
import com.hcl.capstone.rentaplace.exception.PropertyNotFoundException;
import com.hcl.capstone.rentaplace.repository.IPropertyRepository;

@Service
public class PropertyService implements IPropertyService{
	
	@Autowired
	IPropertyRepository propertyRepo;

	@Override
	public List<Property> getAllProperties() {
		// TODO Auto-generated method stub
		return propertyRepo.findAll();
	}

	@Override
	public Property addProperty(Property property) {
		// TODO Auto-generated method stub
		return propertyRepo.save(property);
	}

	@Override
	public String deleteProperty(Long propertyId) {
		// TODO Auto-generated method stub
		propertyRepo.deleteById(propertyId);
		return "Deletion Successful!";
	}

	@Override
	public Property updateProperty(Property property) {
		// TODO Auto-generated method stub
		List<Property> properties = propertyRepo.findAll();
		for(Property p : properties) {
			if(p.getPropertyId() == property.getPropertyId()) {
				p = property;
				break;
			}
		}
		return property;
	}

	@Override
	public Optional<Property> searchProperty(Long propertyId) {
		// TODO Auto-generated method stub
		Optional<Property> property = propertyRepo.findById(propertyId);
		if(property!=null) {
			Optional<Property> propFound = property;
		}else {
			try {
			throw new PropertyNotFoundException();
			}catch(PropertyNotFoundException pnfe) {
				System.out.println("Property Not Found...");
			}
		}
		return property;
	}

	@Override
	public String setAvailablity(Long propertyId) {
		// TODO Auto-generated method stub
		List<Property> properties = propertyRepo.findAll();
		for(Property p : properties) {
			if(p.getPropertyId() == propertyId && p.getAvailability().equals("Available")) {
				p.setAvailability("Available");
				break;
			}
		}
		return propertyRepo.setAvailability(propertyId);
	}

}

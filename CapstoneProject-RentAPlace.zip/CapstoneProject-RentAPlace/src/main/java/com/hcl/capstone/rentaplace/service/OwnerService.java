package com.hcl.capstone.rentaplace.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.capstone.rentaplace.entity.Owner;
import com.hcl.capstone.rentaplace.repository.IOwnerRepository;


@Service
public class OwnerService implements IOwnerService{
	
	@Autowired
	private IOwnerRepository repo;
	
	
	public String Register( Owner owner) {
		
		repo.save(owner);
		return "Registration Successful!";
		
	}


	public Owner login(String ownerName, String ownerPassword) {
		
		return repo.findOwnerByNameAndPassword(ownerName,ownerPassword);
		
	}
	
	
	 public List<Owner> getAll(){
		  return (List<Owner>) repo.findAll();
	  }
	 
	  public String delete(Owner owner) {
		  repo.delete(owner);
		  return "Deletion Successful!";
	  }
	  
	  public Optional<Owner> get(Long ownerId){
		  return repo.findById(ownerId);
	  }
	
	  

}

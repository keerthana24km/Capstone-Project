package com.hcl.capstone.rentaplace.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.capstone.rentaplace.entity.Reserved;
import com.hcl.capstone.rentaplace.service.ReservedService;

@RestController
@RequestMapping("/api/reservedController")
public class ReservedController {

	@Autowired
	ReservedService reservedService;
	
	@GetMapping("reserved/getAllReservations")
	public List<Reserved> getAllReservations(){
		return reservedService.getAllReservations();
	}
}

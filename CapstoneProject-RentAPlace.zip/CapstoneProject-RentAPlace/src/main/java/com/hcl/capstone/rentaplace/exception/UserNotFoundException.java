package com.hcl.capstone.rentaplace.exception;

public class UserNotFoundException extends Exception{

}

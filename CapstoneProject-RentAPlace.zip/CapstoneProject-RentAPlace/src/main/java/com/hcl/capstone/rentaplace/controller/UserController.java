package com.hcl.capstone.rentaplace.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.capstone.rentaplace.entity.User;
import com.hcl.capstone.rentaplace.service.UserService;

@RestController
@RequestMapping("/api/userController")
public class UserController {
	@Autowired
	UserService its;

	@PostMapping("/user/register")
	public String Register(@RequestBody User user) {

		its.Register(user);
		return "Registered Successfully!";
	}

	@PostMapping("/user/login")
	public String Login(@RequestBody User user) {

		User user1 = its.login(user.getUserName(), user.getuserPassword());
		System.out.println(user1);
		if (user1 != null) {
			return "Login Successful";
		} else {
			return "Login Failed";
		}
	}

	@GetMapping("/user/getall")
	public List<User> getAll() {
		List<User> user = its.getAll();
		System.out.println("All Users Retrieved " + user.size());
		return user;
	}

	@PutMapping("/user/edit/{id}")
	public User edit(@PathVariable(value = "id") long id, @RequestBody User user) {
		return its.update(id, user);
	}

	@DeleteMapping("/user/delete/{id}")
	public String delete(@PathVariable(value = "id") long id) {
		Optional<User> i = its.get(id);
		its.delete(i.get());
		return " Deleted Successfully";
	}

}

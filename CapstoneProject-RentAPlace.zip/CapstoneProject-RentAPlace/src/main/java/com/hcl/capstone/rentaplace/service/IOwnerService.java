package com.hcl.capstone.rentaplace.service;

import java.util.List;
import java.util.Optional;

import com.hcl.capstone.rentaplace.entity.Owner;

public interface IOwnerService {
	
	public String Register(Owner owner);
	public Owner login(String ownerName, String ownerPassword);
	public List<Owner> getAll();
	public String delete(Owner owner) ;
	public Optional<Owner> get(Long ownerId);

}

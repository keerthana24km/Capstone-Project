package com.hcl.capstone.rentaplace.service;

import java.util.List;
import java.util.Optional;

import com.hcl.capstone.rentaplace.entity.User;

public interface IUserService {

	public User Register(User user);
	public User login(String userName,String userPassword);
	public List<User> getAll();
	public User update(long id, User user);
	public String delete(User user) ;
	public Optional<User> get(Long userId);
}

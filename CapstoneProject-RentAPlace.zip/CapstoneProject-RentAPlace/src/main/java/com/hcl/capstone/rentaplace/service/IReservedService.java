package com.hcl.capstone.rentaplace.service;

import java.util.List;

import com.hcl.capstone.rentaplace.entity.Reserved;

public interface IReservedService {

	public List<Reserved> getAllReservations();
	
}

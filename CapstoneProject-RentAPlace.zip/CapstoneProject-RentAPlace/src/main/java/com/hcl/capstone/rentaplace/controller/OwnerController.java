package com.hcl.capstone.rentaplace.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.capstone.rentaplace.entity.Owner;
import com.hcl.capstone.rentaplace.service.OwnerService;

@RestController
@RequestMapping("/api/ownerController")
public class OwnerController {
	
	@Autowired
	OwnerService service;
	
	@PostMapping("/owner/register")
	public String register(@RequestBody Owner owner ) {
		
		service.Register(owner);
		return "Registered successfully";
	}
	
	@GetMapping("/owner/login")
	public String login(@RequestBody Owner owner) {
		
		Owner i = service.login(owner.getOwnerName(),owner.getOwnerPassword());
		//System.out.println(i);
		if(i!=null) {
			return "Login Successful!";
		}
		else {
			return "Login Failed";
		}
		
	}
	
	
    @GetMapping("/owner/getall")
  	public List<Owner> getAll(){
  		List<Owner> owner = service.getAll();
  		
  		return owner;
  	}
  	
    
	@DeleteMapping("/owner/delete")
  	public String delete(@RequestBody Owner owner) {
  		Optional<Owner> i = service.get(owner.getOwnerId());
  		service.delete(i.get());
  		return " Deleted successfully";
  	}

}

package com.hcl.capstone.rentaplace.service;

import java.util.List;
import java.util.Optional;

import com.hcl.capstone.rentaplace.entity.Property;

public interface IPropertyService {

	public List<Property> getAllProperties();
	public Property addProperty(Property property);
	public String deleteProperty(Long propertyId);
	public Property updateProperty(Property property);
	public Optional<Property> searchProperty(Long propertyId);
	public String setAvailablity(Long propertyId);
	
}

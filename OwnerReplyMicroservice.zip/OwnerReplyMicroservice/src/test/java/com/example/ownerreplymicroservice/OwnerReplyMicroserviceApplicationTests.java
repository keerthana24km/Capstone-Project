package com.example.ownerreplymicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OwnerReplyMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
